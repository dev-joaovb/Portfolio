<?php return array('dependencies' => array(), 'version' => '1d92b8a230e0f487fd38');
